import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {

	
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","D:\\Workspace\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://jt-dev.azurewebsites.net/#/SignUp");
		driver.findElement(By.id("name")).sendKeys("Shraddha");
		
		driver.findElement(By.id("orgName")).sendKeys("Shraddha");
		driver.findElement(By.id("singUpEmail")).sendKeys("gandhiss9@gmail.com");
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("( document.evaluate('input[@type='checkbox']', XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue).checked =true;");
		
	}

}
